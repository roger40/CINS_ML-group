#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time    : 2020/4/27
# @Author  : Wang Biao
# @Site    :
# @File    : GCN.py
# @Software: PyCharm

'''
define GCN layer
X‘ = f(LXW), f is activation function，L is D^(-1/2)*A'*D^(-1/2)
A' = A+I
'''

import torch
import torch.nn as nn
import torch.nn.init as init

class GCNlayer(nn.Module):
    def __init__(self, input_dim, output_dim, use_bias=None):
        '''
        :param input_dim:
        :param output_dim:
        :param use_bias:
        '''
        super(GCNlayer, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.use_bias = use_bias
        # self.weight = nn.Parameter(torch.Tensor(self.input_dim, self.output_dim))
        # torch.manual_seed(2020)
        self.weight = nn.Parameter(torch.randn(self.input_dim, self.output_dim))
        if self.use_bias:
            self.use_bias = nn.Parameter(torch.randn(self.output_dim, 1))


    def forward(self, adj_norm, input_feature):
        '''

        :param adj_norm:
        :param input_feature:
        :return:
        '''
        support = torch.mm(input_feature, self.weight)
        output = torch.mm(adj_norm, support)
        if self.use_bias:
            output += self.use_bias
        return output






