1: Requirements
python 3.8
torch 1.9.0
numpy 1.19.5
scipy 1.6.2
networkx 2.5
python-louvain 0.15
pickleshare 0.7.5

2: run the demo
python JulyMain_baseongcn.py
python JulyMain_baseongat.py
python JulyMain_dssmgcn.py
python JulyMain_dssmgat.py
