#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time    : 2020/4/27
# @Author  : Wang Biao
# @Site    :
# @File    : JulyMain_baseongat.py
# @Software: PyCharm

'''
PMNRL-GAT
'''

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.utils.data as Data
from GCN import GCNlayer
from GAT import GraphAttentionLayer, SpGraphAttentionLayer
import scipy.sparse as sp
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from JulyLoadData import loadData
import time


class MutiltaskSpGatNet(nn.Module):
    '''
    Define the multi-task-based graph convolution model used, gcn2_1 and gcn2_2 belong to a parallel relationship
    '''
    def __init__(self, input_dim, hidden_dim, output_dim2_1, output_dim2_2, dropout, alpha, nheads, nout_heads):
        '''
        :param input_dim:
        :param hidden_dim:
        :param output_dim2_1:
        :param output_dim2_2:
        :param dropout:
        :param alpha: Parameter of leakyrelu function
        :param nheads: Number of attention mechanisms
        '''
        super(MutiltaskSpGatNet, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.dropout = dropout
        self.alpha = alpha
        self.output_dim2_1 = output_dim2_1
        self.output_dim2_2 = output_dim2_2
        self.nheads = nheads
        self.nout_heads = nout_heads
        '''the first gat layer'''
        self.attentions = [SpGraphAttentionLayer(in_features=self.input_dim, out_features=self.hidden_dim, dropout=self.dropout, alpha=alpha, concat=True) for _ in range(self.nheads)]
        for i, attention in enumerate(self.attentions):
            self.add_module('attention_{}'.format(i), attention)
        '''the second gat layer'''

        self.gat2_1 = SpGraphAttentionLayer(in_features=self.hidden_dim*self.nheads, out_features=self.output_dim2_1, dropout=self.dropout, alpha=alpha, concat=False)

        '''Only set multiple attentions for our main task'''
        # self.gat2_2 = SpGraphAttentionLayer(in_features=self.hidden_dim*self.nheads, out_features=self.output_dim2_2, dropout=self.dropout, alpha=alpha, concat=False)
        self.out_attentions = [SpGraphAttentionLayer(in_features=self.hidden_dim * self.nheads, out_features=self.output_dim2_2, dropout=self.dropout, alpha=alpha, concat=False) for _ in range(self.nout_heads)]

        for i, out_attention in enumerate(self.out_attentions):
            self.add_module('attention_{}'.format(i+self.nheads), out_attention)


    '''
    logits2_1:
    logits2_2:For semi-supervised learning
    '''
    def forward(self, feature_x, adj_norm):
        h = F.dropout(feature_x, self.dropout, training=self.training)
        h = torch.cat([att(h, adj_norm) for att in self.attentions], dim=1)
        logits_share = h
        h = F.dropout(logits_share, self.dropout, training=self.training)
        logits2_1 = F.elu(self.gat2_1(h, adj_norm))
        logits2_2 = F.elu(sum([out_att(h, adj_norm) for out_att in self.out_attentions])/self.nout_heads)
        return logits2_1, logits2_2, logits_share

def normalization(A):
    A = torch.tensor(A, dtype=torch.float)
    A_trans = A + torch.eye(A.size(0), dtype=torch.float)
    rowsum = A_trans.sum(1)
    rowsum_trans = [d ** (-0.5) for d in rowsum]
    D_trans = torch.diag(torch.tensor(rowsum_trans))
    return D_trans.mm(A_trans).mm(D_trans)


def test(model, adj_norm, feature_X, test_x_part, train_y, criterion):
    '''
    :param model:
    :param adj_norm:
    :param feature_X:
    :param test_x:
    :param train_y:
    :return:
    '''
    model.eval()
    with torch.no_grad():
        logits2_1, logits2_2, logits_share = model(feature_X, adj_norm)
        test_x_logits = logits2_2[test_x_part]
        loss = criterion(logits2_2[test_x_part], torch.argmax(train_y[test_x_part], dim=1))
        # 这个错了，没有进行softmax，好像并不影响
        predict_y = test_x_logits.max(1)[1]
        accuracy = torch.eq(predict_y, torch.argmax(train_y[test_x_part], dim=1)).float().mean()
    return accuracy, loss


def train(model, optimizer, epochs, adj_norm, criterion, weight_loss2_1, weight_loss2_2,
          weight_reg_l1, weight_reg_l2,
          feature_X, train_y2_1, train_y2_2, train_x_part, test_x_part, val_x_part,
          result_path, dataset_name):
    '''
    :param model:
    :param epochs:
    :param adj_norm:
    :param criterion:
    :param weight_loss2_1:
    :param weight_loss2_2:
    :param feature_X:
    :param train_y2_1: pseudo label
    :param train_y2_2: true label
    :param train_x_part:
    :param test_x_part:
    :param val_x_part:
    :return:
    '''
    loss_history = []
    loss2_1_history = []
    loss2_2_history = []
    val_loss_history = []
    loss_BNM_history = []
    loss_reg_l1_history = []
    loss_reg_l2_history = []
    train_acc_history = []
    test_acc_history = []
    val_acc_history = []
    params_list = []
    best_loss = 1e9
    best_val_loss = 1e9
    best_test_acc = 0
    best_val_acc = 0
    best_epoch = 0
    for epoch in range(epochs):
        model.train()
        logits2_1, logits2_2, logits_share = model(feature_X, adj_norm)


        loss2_1 = criterion(logits2_1, train_y2_1)

        loss2_2 = criterion(logits2_2[train_x_part], torch.argmax(train_y2_2[train_x_part], dim=1))
        # loss_BNM = -torch.norm(F.softmax(logits2_2, dim=1), 'nuc')*0.5

        '''add l1，l2'''
        # loss_total = weight_loss2_1*loss2_1+weight_loss2_2*loss2_2+weight_reg_l1*l1_reg+weight_reg_l2*l2_reg
        '''no l1, l2'''
        loss_total = weight_loss2_1*loss2_1+weight_loss2_2*loss2_2
        '''add Shared layer parameters l1'''
        # loss_total = weight_loss2_1*loss2_1+weight_loss2_2*loss2_2+weight_reg_l1*gcn1_l1_reg
        loss_total = loss_total.to(device)
        # loss_total = weight_loss2_1*loss2_1+weight_loss2_2*loss2_2+weight_reg*l2_reg
        # print(loss_total)
        optimizer.zero_grad()
        loss_total.backward()
        optimizer.step()
        train_acc, _=test(model=model, adj_norm=adj_norm, feature_X=feature_X, test_x_part=train_x_part, train_y=train_y2_2, criterion=criterion)
        test_acc, _= test(model=model, adj_norm=adj_norm, feature_X=feature_X, test_x_part=test_x_part, train_y=train_y2_2, criterion=criterion)
        val_acc, val_loss= test(model=model, adj_norm=adj_norm, feature_X=feature_X, test_x_part=val_x_part, train_y=train_y2_2, criterion=criterion)

        loss2_1_history.append((weight_loss2_1*loss2_1).item())
        loss2_2_history.append((weight_loss2_2*loss2_2).item())
        # loss_BNM_history.append(loss_BNM.item())
        # loss_reg_history.append(l2_reg.item())
        # loss_reg_l1_history.append((weight_reg_l1*gcn1_l1_reg).item())
        # loss_reg_l2_history.append((weight_reg_l2*l2_reg).item())
        loss_history.append(loss_total.item())
        train_acc_history.append(train_acc.item())
        test_acc_history.append(test_acc.item())
        val_acc_history.append(val_acc.item())
        val_loss_history.append(val_loss.item())
        # print('part_1:', weight_loss2_1*loss2_1, 'part_2:', weight_loss2_2*loss2_2, 'reg:', weight_reg*l2_reg/((feature_X[train_x_part].shape)[0]))

        print('epoch:', epoch, 'Train Loss:', loss_total.item(),
              'Train acc:', train_acc.item(), 'Test acc:', test_acc.item(), 'Val acc:', val_acc.item(), 'Val Loss:', val_loss.item())

        # np.save(result_path+'rep/'+dataset_name+'/'+str(epoch+1)+dataset_name+'_comm_best.npy', logits2_1.detach().cpu().numpy())
        # np.save(result_path+'rep/'+dataset_name+'/'+str(epoch+1)+dataset_name+'_node_best.npy', logits2_2.detach().cpu().numpy())

        if val_acc_history[-1] >= best_val_acc or val_loss_history[-1] <= best_val_loss:
            if val_acc_history[-1] >= best_val_acc and val_loss_history[-1] <= best_val_loss:
                best_epoch = epoch
                best_test_acc = test_acc_history[-1]
                best_val_loss = val_loss_history[-1]
                best_val_acc = val_acc_history[-1]
                best_loss = loss_history[-1]
                # save model
                saved_dict = {
                    'model': model.state_dict(),
                    'opt': optimizer.state_dict()
                }
                # torch.save(saved_dict, result_path+'model/'+dataset_name+'.pt')
                # np.save(result_path + 'rep/' + dataset_name + '_share.npy', logits_share.detach().cpu().numpy())
                # np.save(result_path+'rep/'+dataset_name+'_comm_best.npy', logits2_1.detach().cpu().numpy())
                np.save(result_path+'rep/'+dataset_name+'_node_best.npy', logits2_2.detach().cpu().numpy())

            cnt_wait = 0
        else:

            cnt_wait += 1
        if cnt_wait == 100:
            print('early stop!!!')
            break

    print('best_epoch:', best_epoch)
    print('best_test_acc:', best_test_acc)


    '''
    plt.figure()
    plt.plot(range(1, len(loss_history)+1), loss_history, label='train_loss', color='red')
    plt.legend()
    plt.savefig(result_path + 'picture/' + dataset_name + '_train_loss.png')

    plt.figure()
    plt.plot(range(1, len(val_loss_history)+1), val_loss_history, label='val_loss', color='red')
    plt.legend()
    plt.savefig(result_path+'picture/'+dataset_name+'_val_loss.png')

    # plt.figure()
    # plt.plot(range(1, len(train_acc_history)+1), train_acc_history, label='Train acc', color='green')
    # plt.plot(range(1, len(val_acc_history)+1), val_acc_history, label='Val acc', color='blue')
    # plt.plot(range(1, len(test_acc_history)+1), test_acc_history, label='Test acc', color='yellow')
    # plt.legend()
    # plt.savefig(result_path+'picture/'+dataset_name+'_acc.png')
    # plt.figure()
    # plt.plot(range(1, len(loss2_1_history)+1), loss2_1_history, label='loss2_1_history', color='red')
    # plt.plot(range(1, len(loss2_2_history)+1), loss2_2_history, label='loss2_2_history', color='black')
    # plt.plot(range(1, len(loss_BNM_history)+1), loss_BNM_history, label='loss_BNM_history', color='blue')
    # plt.plot(range(1, len(loss_reg_l1_history)+1), loss_reg_l1_history, label='loss_reg_gcn1_l1_history', color='green')
    # plt.plot(range(1, len(loss_reg_l1_history)+1), loss_reg_l1_history, label='loss_reg_l1_history', color='green')
    # plt.plot(range(1, len(loss_reg_l2_history)+1), loss_reg_l2_history, label='loss_reg_l2_history', color='blue')
    # plt.legend()
    # plt.savefig(result_path+'picture/'+dataset_name+'_all_loss.png')
    # plt.show()
    # '''
    return best_test_acc



if __name__ == '__main__':

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    # device = 'cuda:0'
    # device = 'cuda:1'
    # device = 'cpu'

    print('-------use {}-------'.format(device))
    dataset_name = 'cora'
    # dataset_name = 'citeseer'
    # dataset_name = 'pubmed'
    precent = 1
    method = 'CNM'
    print('-------load {} data--------'.format(dataset_name))
    start = time.time()
    adj, features, y_labels, train_mask, val_mask, test_mask, y_class = loadData(dataset_str=dataset_name, precent=precent, method=method)

    end = time.time()
    print('------finish load--------')
    load_time = end - start
    print('load time:', load_time)

    dropout = 0.4
    weight_decay = 0.03
    learning_rate = 0.009
    weight_loss2_1 = 0.6
    alpha = 0.2
    nheads = 8
    nout_heads = 1
    hidden_dim = 16
    print('dataset_name:', dataset_name)
    print('precent:', precent)
    print('dropout:', dropout)
    print('weight_decay:', weight_decay)
    print('learning_rate:', learning_rate)
    print('weight_loss2_1:', weight_loss2_1)
    print('alpha:', alpha)
    print('nheads:', nheads)
    print('nout_heads:', nout_heads)
    print('hidden_dim:', hidden_dim)
    def main(num, dataset_name, adj, features, y_labels, train_mask, val_mask, test_mask, y_class,
             dropout, weight_decay, learning_rate, weight_loss2_1, alpha, nheads, nout_heads, hidden_dim):
        print('-------num:{}---------'.format(str(num)))
        n, d=features.shape
        '''
        the following parameters
        '''
        dropout = dropout
        weight_decay = weight_decay
        # weight_decay = 5e-4  #pubmed
        # weight_decay = 0
        learning_rate = learning_rate
        # learning_rate = 0.008
        '''the weight of Shared layer parameters'''
        weight_reg_l1 = 10e-4
        '''the weight of Shared layer parameters'''
        weight_reg_l2 = 10e-4
        epochs = 1000
        input_dim = d
        hidden_dim = hidden_dim
        # weight_loss2_1 = 0.5
        weight_loss2_1 = weight_loss2_1  #citeseer，pubmed
        # weight_loss2_1 = 0.4
        weight_loss2_2 = 1
        print('input_dim:', input_dim)
        output_dim2_1 = len(set(y_class))
        print('output_dim2_1:', output_dim2_1)
        output_dim2_2 = y_labels.shape[1]
        print('output_dim2_2:', output_dim2_2)
        alpha = alpha
        nheads = nheads
        # adj_norm = normalization(adj.A).to(device, dtype=torch.float32)
        adj = torch.tensor(adj.A).to(device, dtype=torch.float32)
        adj_norm = adj + torch.eye(adj.size(0)).to(device, dtype=torch.float32)
        feature_X = torch.tensor(features.A).to(device, dtype=torch.float32)


        '''pseudo label'''
        train_y2_1 = torch.tensor(y_class).to(device, torch.long)
        '''train node'''
        train_x_part = torch.tensor(train_mask).to(device)
        '''test node'''
        test_x_part = torch.tensor(test_mask).to(device)
        '''validate node'''
        val_x_part = torch.tensor(val_mask).to(device)
        '''true label'''
        train_y2_2 = torch.tensor(y_labels).to(device)
        dataset_name = dataset_name+'_'+str(precent)+'_'+'717'+'the'+str(num)+'num'

        result_path = './test_result/'

        '''
        the above parameters
        '''

        mutiltask_model = MutiltaskSpGatNet(input_dim=input_dim, hidden_dim=hidden_dim,
                                          output_dim2_1=output_dim2_1, output_dim2_2=output_dim2_2,
                                          dropout=dropout, alpha=alpha, nheads=nheads, nout_heads=nout_heads).to(device)
        # mutiltask_model = torch.nn.DataParallel(mutiltask_model, device_ids=[0,1])
        criterion = nn.CrossEntropyLoss().to(device)
        optimizer = optim.Adam(mutiltask_model.parameters(), lr=learning_rate, weight_decay=weight_decay)
        # optimizer = optim.SGD(mutiltask_model.parameters(), lr=learning_rate)
        best_test_acc = train(model=mutiltask_model, optimizer=optimizer, epochs=epochs, adj_norm=adj_norm,
              criterion=criterion, weight_loss2_1=weight_loss2_1,
              weight_loss2_2=weight_loss2_2, weight_reg_l1=weight_reg_l1, weight_reg_l2=weight_reg_l2,
              feature_X=feature_X, train_y2_1=train_y2_1, train_y2_2=train_y2_2,
              train_x_part=train_x_part,test_x_part=test_x_part, val_x_part=val_x_part,
              result_path=result_path, dataset_name=dataset_name)

        return best_test_acc

    result_list = []
    time_list = []
    for i in range(50):
        # i = i+1
        start = time.time()
        best_test_acc = main(i, dataset_name, adj, features, y_labels, train_mask, val_mask, test_mask, y_class,
                             dropout, weight_decay, learning_rate, weight_loss2_1, alpha, nheads, nout_heads, hidden_dim)
        end = time.time()
        run_time = end - start
        print('the run time of num:{}'.format(str(i)), run_time)
        # exit()
        time_list.append(run_time)
        result_list.append(best_test_acc)
    print('average acc:', np.average(result_list))
    print('std:', np.std(result_list))
    print('load time:', load_time)
    print('average run time:', sum(time_list) / len(time_list))
